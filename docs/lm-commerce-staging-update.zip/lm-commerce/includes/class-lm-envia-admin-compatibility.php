<?php
/**
 * Compatibility fixes for the Envia.com WooCommerce extension admin UI.
 *
 * @package LMCommerce
 */

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class LM_Envia_Admin_Compatibility
{
    public static function init(): void
    {
        // Envia 5.0 enqueues its metabox script while rendering the order screen.
        add_action('admin_print_footer_scripts', array(__CLASS__, 'dequeue_unsafe_metabox_script'), 0);
    }

    public static function dequeue_unsafe_metabox_script(): void
    {
        if (! function_exists('get_current_screen')) {
            return;
        }

        $screen = get_current_screen();
        if (! $screen || ! in_array($screen->id, array('shop_order', 'woocommerce_page_wc-orders'), true)) {
            return;
        }

        /*
         * The official `orderBox` script uses an unbounded while loop to move
         * Envia's metabox. It never terminates with WooCommerce's HPOS layout,
         * freezing the browser. The metabox markup and its quote link work
         * without this cosmetic reordering script.
         */
        wp_dequeue_script('orderBox');
    }
}
